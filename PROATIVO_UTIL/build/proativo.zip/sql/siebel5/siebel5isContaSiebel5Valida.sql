SELECT  1
  FROM s_org_ext soe
  where soe.x_acct_id_num in (?);
  