delete
from proativo_scripts
where id_execucao = ?;