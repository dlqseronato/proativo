SELECT account_category FROM proativo_segmentos
where  TRATAR_COM = ?;