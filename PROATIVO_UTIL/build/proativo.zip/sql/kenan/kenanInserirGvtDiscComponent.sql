insert into arborgvt_billing.gvt_disc_component(serv_inst, package_id, component_instance_id, end_date, run_status, ext_id_type_inst, rotina) 
values(?, ?, ?, ?, 99, ?, ?)