select 1
from service_view
where parent_account_no = ?
and view_status = 1;