update ###TABELA###
set view_status = 4
where ###PARAMETRO### = ?
and view_status = 1;