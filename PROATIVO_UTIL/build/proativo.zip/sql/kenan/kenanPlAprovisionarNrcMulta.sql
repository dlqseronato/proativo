declare 
v_tid  int;
v_tids int;
begin    
 arbor.nrc_insert(?, ?, ?, null, 1, ?, ?, ?, user, ?, 0, v_tid, v_tids, ?);
 end;
 commit;
/