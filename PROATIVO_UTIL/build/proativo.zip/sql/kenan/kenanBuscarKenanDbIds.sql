select
	server_id-2 kenan_db_id
from server_definition
where ds_database like '%CT%'