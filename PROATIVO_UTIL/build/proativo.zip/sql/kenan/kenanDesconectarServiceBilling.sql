update service_billing
set inactive_dt = ?
where subscr_no = ?;