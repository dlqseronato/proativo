insert into arborgvt_billing.gvt_prov_charges
(element_id, extid_acctno, ext_id_type, package_id, component_id, start_date, end_date, flag, run_status, user_insert, user_update, rotina, jurisdiction, units, units_type) 
values
(' ', ?, ?, ?, ?, ?, ?, ?, 99, user, user, ?, ?, ?, ?) 