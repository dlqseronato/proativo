delete 
from arborgvt_billing.gvt_disc_component
where component_instance_id = ?