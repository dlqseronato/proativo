update cmf_component_element set inactive_dt = ? where component_inst_id = ? and component_inst_id_serv = ? ;
