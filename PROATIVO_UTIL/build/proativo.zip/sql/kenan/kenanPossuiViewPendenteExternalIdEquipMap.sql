select *
from external_id_equip_map_view
where subscr_no = ?
and view_status = 1;