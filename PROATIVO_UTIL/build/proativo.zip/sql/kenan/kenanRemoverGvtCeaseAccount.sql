delete
from ARBORGVT_BILLING.gvt_cease_account
where	serv_inst = ?
	and external_acct_id = ?